---
name: Warm Intellectualism
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#55433d'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#88726c'
  outline-variant: '#dbc1b9'
  surface-tint: '#99462a'
  primary: '#99462a'
  on-primary: '#ffffff'
  primary-container: '#d97757'
  on-primary-container: '#541400'
  inverse-primary: '#ffb59e'
  secondary: '#9b4428'
  on-secondary: '#ffffff'
  secondary-container: '#fd916e'
  on-secondary-container: '#75280e'
  tertiary: '#6b5c4c'
  on-tertiary: '#ffffff'
  tertiary-container: '#a18f7d'
  on-tertiary-container: '#35291b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59e'
  on-primary-fixed: '#390b00'
  on-primary-fixed-variant: '#7a2f15'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#3a0b00'
  on-secondary-fixed-variant: '#7c2e13'
  tertiary-fixed: '#f4dfcb'
  tertiary-fixed-dim: '#d7c3b0'
  on-tertiary-fixed: '#241a0d'
  on-tertiary-fixed-variant: '#524436'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  display:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Manrope
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an aura of calm, measured intelligence. Drawing inspiration from modern editorial publishing, research journals, and humanistic computing, it avoids cold, sterile corporate tech cues in favor of organic warmth and tactile clarity. 

The interface reflects thoughtful craftsmanship: scholarly yet accessible, patient, and unhurried. The visual aesthetic pairs minimalist surface structures with high-touch typography, delivering an experience that feels closer to holding a bespoke linen notebook or reading an archival monograph than interacting with traditional utility software.

## Colors

The palette operates exclusively in light mode, anchored by warm, parchment-like backgrounds and balanced by earthy accents:

- **Canvas & Surfaces:** Base ground is `#FAF9F6`, stepping into `#F5F0E8` for subtle surface elevations and container fills. Recessed panels or subtle interactive wells rest at `#ECE6DC`.
- **Primary Accent (`#D97757`):** A warm, sun-baked terracotta used purposefully for key interactive touchpoints, primary actions, and focused states.
- **Secondary Accent (`#C26243`):** Deep burnt clay providing intentional contrast for active or hovered states of primary elements.
- **Tertiary Accent (`#8A7968`):** Muted umber-olive for quiet metadata, secondary indicators, and muted tags.
- **Ink / Typography:** Strict pure black (`#000000`) is avoided. Main body text uses deep charcoal-espresso (`#24211E`), with secondary copy resting at `#59534C` and disabled or placeholder copy at `#9E968D`.

## Typography

The pairing combines the literary authority of **Newsreader** (used for displays and titles) with the clean, balanced legibility of **Manrope** (for body copy, controls, and labels). 

Headlines feature relaxed, expressive proportions with optical sizing considerations. Body copy prioritizes generous line-heights to support fatigue-free, long-form reading. Italic variations in Newsreader are reserved for editorial accents, reflective prompts, or philosophical quotes.

## Layout & Spacing

The layout philosophy follows a disciplined, centered reading column structure that expands gracefully into multi-pane arrangements on wider canvases:

- **Rhythm & Grid:** Built on an 8pt base grid. Text content defaults to comfortable max-width constraints (680px–740px) to mirror classical editorial margins.
- **Breakpoints:**
  - **Desktop (≥ 1024px):** Generous 40px (`2.5rem`) outer canvas margins, 24px (`1.5rem`) gutters, with fixed or proportional toolbars flanking a calm, centered reading track.
  - **Tablet (640px – 1023px):** Fluid grid with 24px margins; secondary panes collapse into overlay panels or sequential stages.
  - **Mobile (< 640px):** Single-column layout with 20px (`1.25rem`) edge padding, maximizing touch-accessible breathing room.

## Elevation & Depth

Visual depth is achieved through layered tonal planes and diffused, sunlight-tinted ambient shadows rather than high-contrast dividing lines:

- **Tonal Layering:** The primary canvas sits at `#FAF9F6`. Elevated cards and toolbars shift to `#FFFFFF` or `#F5F0E8` depending on role, creating a natural hierarchy through warmth and brightness.
- **Ambient Warm Shadows:** Shadows discard sterile neutral grays. They use warm, amber-tinted undertones (`rgba(44, 34, 25, 0.04)` to `rgba(44, 34, 25, 0.08)`) with broad blur radii (16px–32px) and minimal vertical offset (2px–6px) to emulate gentle overhead light falling on heavy cardstock.
- **Whisper Borders:** Borders are deployed sparingly, using warm, translucent taupe tones (`rgba(72, 60, 50, 0.08)`) to preserve surface separation without cluttering the visual field.

## Shapes

The shape system employs rounded corners (8px base, scaling to 16px and 24px for macro containers). Corners feel organic and inviting, removing harsh industrial points without dissolving into overly playful pill forms. 

Inputs and contextual chips inherit softer, unified radiuses to evoke comfortable pebble-like tactility.

## Components

- **Buttons:** 
  - *Primary:* Filled with `#D97757` and warm white text (`#FAF9F6`), transitioning to `#C26243` on hover with a smooth 150ms ease. Rounded to `0.5rem`.
  - *Secondary / Ghost:* Unfilled with subtle borders (`rgba(72, 60, 50, 0.12)`) on `#F5F0E8` hover, retaining warm ink text (`#24211E`).
- **Input Fields & Chat Composer:** Built as grounded `#FFFFFF` or elevated `#FAF9F6` rounded containers (`1rem` radius) with `1px` borders in `rgba(72, 60, 50, 0.1)`. Focus states substitute harsh rings with a soft terracotta glow (`rgba(217, 119, 87, 0.25)`).
- **Cards & Conversational Artifacts:** Surface `#FFFFFF` layered against the `#FAF9F6` canvas. Outlines remain at or below 0.06 opacity. Padding utilizes `1.5rem` (`space-lg`) to foster room for comprehension.
- **Chips & Tags:** Small, subtle capsules rendered in `#F5F0E8` with `#59534C` text, functioning as understated categorical cues.
- **Checkboxes & Radios:** Rounded forms using terracotta accents only when actively checked; resting state uses a quiet bone-neutral border.
- **Reading Callouts & Artifact Panes:** Dedicated side-drawers or inset callout blocks using `#F5F0E8` backgrounds with delicate left-border rules in `#D97757` to signal synthesized knowledge, quotes, or code references.