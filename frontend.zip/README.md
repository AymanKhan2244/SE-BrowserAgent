# SE BrowserAgent Frontend (ForgeAI Dashboard)

Next.js 14 Web Application built with TypeScript, Tailwind CSS, and Lucide Icons for the SE BrowserAgent / ForgeAI Code Generation Platform.

---

## 🚀 Overview

This frontend provides an interactive, state-of-the-art dashboard for autonomous software engineering workflows:
- **Workspace & Agent Workflow:** Live stage-by-stage visualization of Planner, Architect, Coder, Debugger, Terminal, and Playwright Browser testing agents.
- **Code & Project Inspector:** Multi-file syntax-highlighted code viewer and real-time live preview iframe.
- **New Task Studio:** Prompt engineering interface with architectural parameters, tech stack selection, and execution controls.
- **Tasks & History:** Complete ledger of generated applications with runtime metrics and download options.

---

## 🛠️ Tech Stack

- **Framework:** Next.js 14 (App Router)
- **UI Library:** React 18 & TypeScript
- **Styling:** Tailwind CSS 3 with custom dark theme, neon glows, and JetBrains Mono typography
- **Icons:** Lucide React

---

## 📦 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

> In development mode, `next.config.js` automatically proxies API endpoints (`/api/*`) and previews (`/preview/*`) to the backend at `http://localhost:8000`.

### 3. Production Build / Static Export
```bash
npm run build
```

This generates the static export in the `out/` folder (also pre-included in this zip archive), ready to be served by FastAPI, Nginx, or any static hosting provider.
