from dataclasses import dataclass
from datetime import datetime
from typing import Optional

@dataclass
class TodoItem:
    """
    Represents a todo item.

    Attributes:
        id (int): The unique identifier of the todo item.
        title (str): The title of the todo item.
        description (str): The description of the todo item.
        due_date (Optional[datetime]): The due date of the todo item.
        completed (bool): Whether the todo item is completed.
    """
    id: int
    title: str
    description: str
    due_date: Optional[datetime]
    completed: bool

    def to_dict(self) -> dict:
        """
        Converts the todo item to a dictionary.

        Returns:
            dict: The todo item as a dictionary.
        """
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "due_date": self.due_date.isoformat() if self.due_date else None,
            "completed": self.completed
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TodoItem":
        """
        Creates a todo item from a dictionary.

        Args:
            data (dict): The dictionary containing the todo item data.

        Returns:
            TodoItem: The created todo item.
        """
        try:
            due_date = datetime.fromisoformat(data["due_date"]) if data.get("due_date") else None
            return cls(
                id=data["id"],
                title=data["title"],
                description=data["description"],
                due_date=due_date,
                completed=data["completed"]
            )
        except KeyError as e:
            raise ValueError(f"Missing required key: {e}")
        except ValueError as e:
            raise ValueError(f"Invalid value: {e}")