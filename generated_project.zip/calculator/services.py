import ast
from typing import Union


class CalculationError(Exception):
    """Exception raised for errors that occur during expression evaluation."""

    pass


def _evaluate_node(node: ast.AST) -> Union[int, float]:
    """
    Recursively evaluate an AST node representing a safe arithmetic expression.

    Supported operations:
        - Addition (+)
        - Subtraction (-)
        - Multiplication (*)
        - Division (/)
        - Unary plus (+) and minus (-)
        - Parentheses (via grouping in the AST)

    Args:
        node: The AST node to evaluate.

    Returns:
        The numeric result of evaluating the node.

    Raises:
        CalculationError: If the node contains unsupported operations or invalid data.
    """
    if isinstance(node, ast.Expression):
        return _evaluate_node(node.body)

    if isinstance(node, ast.BinOp):
        left = _evaluate_node(node.left)
        right = _evaluate_node(node.right)

        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise CalculationError("Division by zero.")
            return left / right

        raise CalculationError(f"Unsupported binary operator: {type(node.op).__name__}")

    if isinstance(node, ast.UnaryOp):
        operand = _evaluate_node(node.operand)
        if isinstance(node.op, ast.UAdd):
            return +operand
        if isinstance(node.op, ast.USub):
            return -operand
        raise CalculationError(f"Unsupported unary operator: {type(node.op).__name__}")

    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise CalculationError(f"Unsupported constant type: {type(node.value).__name__}")

    # For Python <3.8 compatibility where ast.Num is used
    if isinstance(node, ast.Num):  # pragma: no cover
        return node.n

    raise CalculationError(f"Unsupported expression element: {type(node).__name__}")


def evaluate_expression(expression: str) -> float:
    """
    Safely evaluate a simple arithmetic expression.

    The function parses the expression using Python's ``ast`` module and
    evaluates it while allowing only a limited set of operations to prevent
    arbitrary code execution.

    Args:
        expression: A string containing the arithmetic expression to evaluate.

    Returns:
        The result of the expression as a float.

    Raises:
        CalculationError: If the expression is malformed, contains unsupported
            operations, or results in a runtime error such as division by zero.
    """
    if not isinstance(expression, str):
        raise CalculationError("Expression must be a string.")

    # Strip whitespace to avoid unnecessary parsing issues
    cleaned_expr = expression.strip()
    if not cleaned_expr:
        raise CalculationError("Empty expression.")

    try:
        parsed = ast.parse(cleaned_expr, mode="eval")
    except SyntaxError as exc:
        raise CalculationError(f"Invalid syntax: {exc.msg}") from exc

    result = _evaluate_node(parsed)
    # Ensure a numeric type is returned
    if not isinstance(result, (int, float)):
        raise CalculationError("Expression did not evaluate to a numeric result.")

    return float(result)


__all__ = ["evaluate_expression", "CalculationError"]