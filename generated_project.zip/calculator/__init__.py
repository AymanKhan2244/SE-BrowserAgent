"""Calculator Blueprint package.

This module creates the Flask :class:`~flask.Blueprint` used for the
calculator API and ensures that all route definitions are imported
and registered. Importing this module registers the routes automatically,
so the application entry point can simply register the blueprint.

Typical usage in the application factory::

    from flask import Flask
    from calculator import calculator_bp

    app = Flask(__name__)
    app.register_blueprint(calculator_bp)

"""

from flask import Blueprint

# Create the blueprint that will hold all calculator related routes.
calculator_bp: Blueprint = Blueprint(
    "calculator", __name__, url_prefix="/"
)

# Import the routes module so that route handlers are attached to the
# ``calculator_bp`` blueprint. The import must occur after the blueprint
# is defined to avoid circular import issues.
from . import routes  # noqa: F401  (imported for side‑effects)

__all__: list[str] = ["calculator_bp"]