from flask import request, jsonify
from flask_cors import cross_origin

from . import bp
from .services import evaluate_expression


@bp.route("/api/calculate", methods=["POST"])
@cross_origin()
def calculate() -> tuple[dict[str, float] | dict[str, str], int]:
    """
    Evaluate a mathematical expression sent by the client.

    Expects a JSON payload:
        {
            "expression": "2 + 3 * (4 - 1)"
        }

    Returns JSON:
        Success -> {"result": <float>}
        Error   -> {"error": "<error message>"}

    HTTP status codes:
        200 – successful evaluation
        400 – client‑side error (bad JSON, missing/invalid expression, evaluation error)
        500 – unexpected server error
    """
    if not request.is_json:
        return jsonify(error="Invalid content type: application/json required"), 400

    payload = request.get_json(silent=True) or {}
    expression = payload.get("expression")

    if not isinstance(expression, str) or not expression.strip():
        return jsonify(error="Missing or invalid 'expression' field"), 400

    try:
        result = evaluate_expression(expression)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except Exception:  # pragma: no cover
        # Unexpected error – log in real deployment
        return jsonify(error="Internal server error"), 500

    return jsonify(result=result), 200