from __future__ import annotations

import logging
import os
from typing import Any, Dict, Literal

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

# Define allowed operations
Operation = Literal["add", "subtract", "multiply", "divide"]

# Configure basic logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    """
    Create and configure the Flask application.

    Returns:
        Flask: Configured Flask app instance.
    """
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    CORS(app)  # Enable Cross-Origin Resource Sharing for all routes

    @app.route("/", methods=["GET"])
    def serve_index() -> Any:
        """
        Serve the main HTML page for the calculator UI.

        Returns:
            Flask response: The index.html file.
        """
        logger.info("Serving index.html")
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/calculate", methods=["POST"])
    def calculate() -> Any:
        """
        Perform a calculation based on JSON payload.

        Expected JSON payload:
        {
            "a": <number>,
            "b": <number>,
            "op": "add" | "subtract" | "multiply" | "divide"
        }

        Returns:
            JSON response with the result or an error message.
        """
        if not request.is_json:
            logger.warning("Request content type is not JSON")
            return jsonify({"error": "Request body must be JSON"}), 400

        try:
            data: Dict[str, Any] = request.get_json()
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to parse JSON payload")
            return jsonify({"error": "Invalid JSON payload"}), 400

        if not isinstance(data, dict):
            logger.warning("JSON payload is not an object")
            return jsonify({"error": "JSON payload must be an object"}), 400

        try:
            a_raw = data["a"]
            b_raw = data["b"]
            op_raw = data["op"]
        except KeyError as exc:
            missing = exc.args[0]
            logger.warning("Missing field in payload: %s", missing)
            return jsonify({"error": f"Missing field: {missing}"}), 400

        # Validate operation
        if op_raw not in {"add", "subtract", "multiply", "divide"}:
            logger.warning("Invalid operation requested: %s", op_raw)
            return (
                jsonify(
                    {
                        "error": f"Invalid operation '{op_raw}'. Allowed: add, subtract, multiply, divide"
                    }
                ),
                400,
            )

        # Convert numbers
        try:
            a = float(a_raw)
            b = float(b_raw)
        except (TypeError, ValueError):
            logger.warning("Non-numeric operands: a=%s, b=%s", a_raw, b_raw)
            return jsonify({"error": "Fields 'a' and 'b' must be numeric"}), 400

        # Perform calculation
        try:
            result = _perform_operation(a, b, op_raw)  # type: ignore[arg-type]
        except ZeroDivisionError:
            logger.warning("Division by zero attempt")
            return jsonify({"error": "Division by zero is not allowed"}), 400
        except Exception:  # noqa: BLE001
            logger.exception("Unexpected error during calculation")
            return jsonify({"error": "Internal server error"}), 500

        logger.info("Calculation successful: %s %s %s = %s", a, op_raw, b, result)
        return jsonify({"result": result})

    @app.errorhandler(404)
    def not_found(error: Any) -> Any:
        logger.warning("404 Not Found: %s", request.path)
        return jsonify({"error": "Resource not found"}), 404

    @app.errorhandler(405)
    def method_not_allowed(error: Any) -> Any:
        logger.warning("405 Method Not Allowed: %s %s", request.method, request.path)
        return jsonify({"error": "Method not allowed"}), 405

    return app


def _perform_operation(a: float, b: float, op: Operation) -> float:
    """
    Execute the arithmetic operation.

    Args:
        a (float): First operand.
        b (float): Second operand.
        op (Operation): Operation identifier.

    Returns:
        float: Result of the calculation.
    """
    if op == "add":
        return a + b
    if op == "subtract":
        return a - b
    if op == "multiply":
        return a * b
    if op == "divide":
        return a / b
    raise ValueError(f"Unsupported operation: {op}")


app = create_app()

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)