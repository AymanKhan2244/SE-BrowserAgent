import json
from typing import Any, Dict

from flask import Flask, jsonify, request, render_template, abort
from flask_cors import CORS

# Import arithmetic functions from the calculator service
try:
    from services.calculator import add, subtract, multiply, divide
except ImportError as e:
    raise ImportError(
        "Failed to import calculator functions. Ensure that "
        "'services/calculator.py' exists and defines 'add', 'subtract', "
        "'multiply', and 'divide' functions."
    ) from e

app = Flask(__name__, static_folder="static", template_folder="templates")
# Enable CORS for all routes (frontend and API may be served from same origin)
CORS(app)


def _parse_float(value: Any) -> float:
    """
    Convert a value to float, raising a ValueError with a clear message if conversion fails.
    """
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Value '{value}' is not a valid number.") from exc


@app.route("/", methods=["GET"])
def index() -> Any:
    """
    Render the main calculator UI.
    """
    return render_template("index.html")


@app.route("/api/calculate", methods=["POST"])
def calculate() -> Any:
    """
    API endpoint that receives a JSON payload with two numbers and an operation,
    performs the calculation using the calculator service, and returns the result.

    Expected JSON payload:
    {
        "number1": <numeric>,
        "number2": <numeric>,
        "operation": "add" | "subtract" | "multiply" | "divide"
    }

    Returns:
        JSON response with either {"result": <number>} or {"error": <message>}.
    """
    if not request.is_json:
        return jsonify(error="Request body must be JSON."), 400

    data: Dict[str, Any] = request.get_json(silent=True) or {}
    required_fields = {"number1", "number2", "operation"}

    missing = required_fields - data.keys()
    if missing:
        return jsonify(error=f"Missing fields: {', '.join(sorted(missing))}."), 400

    try:
        num1 = _parse_float(data["number1"])
        num2 = _parse_float(data["number2"])
    except ValueError as ve:
        return jsonify(error=str(ve)), 400

    operation = str(data["operation"]).lower()
    try:
        if operation == "add":
            result = add(num1, num2)
        elif operation == "subtract":
            result = subtract(num1, num2)
        elif operation == "multiply":
            result = multiply(num1, num2)
        elif operation == "divide":
            result = divide(num1, num2)
        else:
            return jsonify(error="Invalid operation. Choose add, subtract, multiply, or divide."), 400
    except ZeroDivisionError:
        return jsonify(error="Division by zero is not allowed."), 400
    except Exception as exc:
        # Unexpected errors from the service layer
        return jsonify(error=f"Calculation error: {str(exc)}"), 500

    # Ensure result is JSON serializable (float/int)
    return jsonify(result=result)


@app.errorhandler(404)
def not_found(error):
    """
    Return a JSON response for 404 errors.
    """
    return jsonify(error="Resource not found."), 404


@app.errorhandler(405)
def method_not_allowed(error):
    """
    Return a JSON response for 405 errors.
    """
    return jsonify(error="Method not allowed."), 405


def create_app() -> Flask:
    """
    Factory function to create a Flask app instance.
    This is useful for testing or when the app is imported elsewhere.
    """
    return app


if __name__ == "__main__":
    # Run the development server; in production, use a WSGI server like gunicorn.
    app.run(host="0.0.0.0", port=5000, debug=True)