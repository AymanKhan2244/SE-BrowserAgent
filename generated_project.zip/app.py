from flask import Flask, render_template, request, jsonify
from services.todo_service import TodoService
from routes.todo_routes import todo_routes
import logging

app = Flask(__name__)
app.config['SECRET_KEY'] = 'todo-app-secret-key'

# Register todo routes
app.register_blueprint(todo_routes)

# Initialize todo service
todo_service = TodoService()

# CORS handling
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# Index route
@app.route('/', methods=['GET'])
def index() -> str:
    try:
        return render_template('index.html')
    except Exception as e:
        logging.error(f"Error rendering index.html: {e}")
        return jsonify({"error": "Failed to render index.html"}), 500

# Error handling
@app.errorhandler(404)
def page_not_found(e):
    return jsonify({"error": "Page not found"}), 404

@app.errorhandler(500)
def internal_server_error(e):
    return jsonify({"error": "Internal server error"}), 500

# Run the application
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    app.run(debug=True)