import logging
from typing import Any

from flask import Flask, jsonify
from flask_cors import CORS

# Import the calculator blueprint defined in the package
# The blueprint is expected to be named `calculator_bp` in calculator/__init__.py
try:
    from calculator import calculator_bp
except ImportError as exc:
    raise ImportError(
        "Failed to import the calculator blueprint. Ensure that "
        "`calculator/__init__.py` defines `calculator_bp`."
    ) from exc


def create_app() -> Flask:
    """
    Application factory that creates and configures the Flask app.

    Returns
    -------
    Flask
        Configured Flask application instance.
    """
    app = Flask(
        __name__,
        static_folder="static",
        template_folder="templates",
    )

    # Enable CORS for all routes (frontend may be served from a different origin)
    CORS(app)

    # Register the calculator blueprint under the root URL prefix
    app.register_blueprint(calculator_bp, url_prefix="/")

    # Basic health‑check endpoint
    @app.route("/health", methods=["GET"])
    def health_check() -> Any:
        """Simple health check returning a JSON payload."""
        return jsonify({"status": "ok"}), 200

    # Global error handler to return JSON for unhandled exceptions
    @app.errorhandler(Exception)
    def handle_exception(error: Exception) -> Any:
        """Return JSON response for any uncaught exception."""
        app.logger.exception("Unhandled exception: %s", error)
        response = {
            "error": "Internal Server Error",
            "message": str(error),
        }
        return jsonify(response), 500

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(threadName)s : %(message)s",
    )
    app.logger.setLevel(logging.INFO)

    return app


# Create the app instance when the module is executed directly
if __name__ == "__main__":
    flask_app = create_app()
    # Use host 0.0.0.0 to be reachable from Docker or external hosts
    flask_app.run(host="0.0.0.0", port=5000, debug=False)