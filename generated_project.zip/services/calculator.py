from __future__ import annotations

from typing import Callable, Dict


class CalculatorError(Exception):
    """Base exception for calculator errors."""

    pass


def _validate_number(value: float | int, name: str) -> float:
    """
    Validate that the provided value is a number (int or float) and return it as a float.

    Args:
        value: The value to validate.
        name: The name of the parameter (used for error messages).

    Returns:
        The value converted to float.

    Raises:
        CalculatorError: If the value is not a number.
    """
    if isinstance(value, (int, float)):
        return float(value)
    raise CalculatorError(f"'{name}' must be a numeric type, got {type(value).__name__}.")


def add(a: float | int, b: float | int) -> float:
    """
    Return the sum of two numbers.

    Args:
        a: First addend.
        b: Second addend.

    Returns:
        The sum as a float.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    a_val = _validate_number(a, "a")
    b_val = _validate_number(b, "b")
    return a_val + b_val


def subtract(a: float | int, b: float | int) -> float:
    """
    Return the difference of two numbers (a - b).

    Args:
        a: Minuend.
        b: Subtrahend.

    Returns:
        The difference as a float.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    a_val = _validate_number(a, "a")
    b_val = _validate_number(b, "b")
    return a_val - b_val


def multiply(a: float | int, b: float | int) -> float:
    """
    Return the product of two numbers.

    Args:
        a: First factor.
        b: Second factor.

    Returns:
        The product as a float.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    a_val = _validate_number(a, "a")
    b_val = _validate_number(b, "b")
    return a_val * b_val


def divide(a: float | int, b: float | int) -> float:
    """
    Return the quotient of two numbers (a / b).

    Args:
        a: Dividend.
        b: Divisor.

    Returns:
        The quotient as a float.

    Raises:
        CalculatorError: If either argument is not numeric or if division by zero is attempted.
    """
    a_val = _validate_number(a, "a")
    b_val = _validate_number(b, "b")
    if b_val == 0.0:
        raise CalculatorError("Division by zero is not allowed.")
    return a_val / b_val


# Mapping of operation names to functions for convenience
_OPERATIONS: Dict[str, Callable[[float | int, float | int], float]] = {
    "add": add,
    "subtract": subtract,
    "multiply": multiply,
    "divide": divide,
}


def calculate(operation: str, a: float | int, b: float | int) -> float:
    """
    Perform a calculation based on the given operation name.

    Args:
        operation: One of 'add', 'subtract', 'multiply', 'divide'.
        a: First operand.
        b: Second operand.

    Returns:
        The result of the operation as a float.

    Raises:
        CalculatorError: If the operation is unsupported or any operand is invalid.
    """
    func = _OPERATIONS.get(operation.lower())
    if func is None:
        raise CalculatorError(f"Unsupported operation '{operation}'. Supported operations: {', '.join(_OPERATIONS)}")
    return func(a, b)


__all__ = [
    "CalculatorError",
    "add",
    "subtract",
    "multiply",
    "divide",
    "calculate",
]