import logging
from typing import List, Dict, Optional

class TodoService:
    """
    This class owns the todo item business logic.
    It provides methods to create, read, update and delete todo items.
    """

    def __init__(self):
        """
        Initializes the TodoService with an empty list of todo items.
        """
        self.todo_items: List[Dict] = []
        self.logger = logging.getLogger(__name__)

    def create_todo_item(self, title: str, description: str) -> Dict:
        """
        Creates a new todo item with the given title and description.

        Args:
            title (str): The title of the todo item.
            description (str): The description of the todo item.

        Returns:
            Dict: The created todo item.
        """
        try:
            todo_item = {
                "id": len(self.todo_items) + 1,
                "title": title,
                "description": description,
                "completed": False
            }
            self.todo_items.append(todo_item)
            return todo_item
        except Exception as e:
            self.logger.error(f"Failed to create todo item: {str(e)}")
            raise

    def get_all_todo_items(self) -> List[Dict]:
        """
        Retrieves all todo items.

        Returns:
            List[Dict]: A list of all todo items.
        """
        try:
            return self.todo_items.copy()
        except Exception as e:
            self.logger.error(f"Failed to get all todo items: {str(e)}")
            raise

    def get_todo_item(self, id: int) -> Optional[Dict]:
        """
        Retrieves a todo item by its id.

        Args:
            id (int): The id of the todo item.

        Returns:
            Optional[Dict]: The todo item with the given id, or None if not found.
        """
        try:
            for todo_item in self.todo_items:
                if todo_item["id"] == id:
                    return todo_item.copy()
            return None
        except Exception as e:
            self.logger.error(f"Failed to get todo item with id {id}: {str(e)}")
            raise

    def update_todo_item(self, id: int, title: Optional[str] = None, description: Optional[str] = None, completed: Optional[bool] = None) -> Optional[Dict]:
        """
        Updates a todo item with the given id.

        Args:
            id (int): The id of the todo item.
            title (Optional[str], optional): The new title of the todo item. Defaults to None.
            description (Optional[str], optional): The new description of the todo item. Defaults to None.
            completed (Optional[bool], optional): The new completed status of the todo item. Defaults to None.

        Returns:
            Optional[Dict]: The updated todo item, or None if not found.
        """
        try:
            for todo_item in self.todo_items:
                if todo_item["id"] == id:
                    if title:
                        todo_item["title"] = title
                    if description:
                        todo_item["description"] = description
                    if completed is not None:
                        todo_item["completed"] = completed
                    return todo_item.copy()
            return None
        except Exception as e:
            self.logger.error(f"Failed to update todo item with id {id}: {str(e)}")
            raise

    def delete_todo_item(self, id: int) -> bool:
        """
        Deletes a todo item with the given id.

        Args:
            id (int): The id of the todo item.

        Returns:
            bool: True if the todo item was deleted, False if not found.
        """
        try:
            for i, todo_item in enumerate(self.todo_items):
                if todo_item["id"] == id:
                    del self.todo_items[i]
                    return True
            return False
        except Exception as e:
            self.logger.error(f"Failed to delete todo item with id {id}: {str(e)}")
            raise