document.addEventListener('DOMContentLoaded', () => {
  /** @type {HTMLFormElement | null} */
  const form = document.getElementById('calc-form');
  /** @type {HTMLElement | null} */
  const resultContainer = document.getElementById('result');

  if (!form) {
    console.error('Calculator form not found (expected id="calc-form")');
    return;
  }

  if (!resultContainer) {
    console.error('Result container not found (expected id="result")');
    return;
  }

  /**
   * Displays a message in the result container.
   * @param {string} message
   * @param {boolean} [isError=false]
   */
  function displayResult(message, isError = false) {
    resultContainer.textContent = message;
    resultContainer.style.color = isError ? 'red' : 'inherit';
  }

  /**
   * Sends calculation request to the backend.
   * @param {number} a
   * @param {number} b
   * @param {string} op
   * @returns {Promise<number>}
   */
  async function requestCalculation(a, b, op) {
    const payload = { a, b, op };
    const response = await fetch('/calculate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Include CSRF token header if your backend requires it.
      },
      body: JSON.stringify(payload),
      credentials: 'same-origin',
    });

    if (!response.ok) {
      const errorText = await response.text().catch(() => response.statusText);
      throw new Error(`Server responded with ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    if (typeof data.result !== 'number') {
      throw new Error('Invalid response format: missing numeric "result" field');
    }
    return data.result;
  }

  /**
   * Handles form submission.
   * @param {Event} event
   */
  async function handleSubmit(event) {
    event.preventDefault();

    const formData = new FormData(form);
    const aStr = formData.get('a')?.toString().trim() ?? '';
    const bStr = formData.get('b')?.toString().trim() ?? '';
    const op = (formData.get('op')?.toString().trim() ?? '+').toLowerCase();

    const a = Number(aStr);
    const b = Number(bStr);

    if (Number.isNaN(a) || Number.isNaN(b)) {
      displayResult('Both operands must be valid numbers.', true);
      return;
    }

    try {
      displayResult('Calculating...');
      const result = await requestCalculation(a, b, op);
      displayResult(`Result: ${result}`);
    } catch (err) {
      console.error('Calculation error:', err);
      displayResult(err instanceof Error ? err.message : 'An unexpected error occurred.', true);
    }
  }

  form.addEventListener('submit', handleSubmit);
});