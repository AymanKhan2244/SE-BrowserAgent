// static/js/app.js

/**
 * Frontend controller for the basic calculator.
 * Handles button clicks, keyboard input, builds the arithmetic expression,
 * sends it to the Flask backend, and updates the display with the result.
 */

document.addEventListener('DOMContentLoaded', () => {
  /** @type {HTMLElement} */
  const display = document.getElementById('display');
  /** @type {NodeListOf<HTMLButtonElement>} */
  const buttons = document.querySelectorAll('.calc-btn');

  /** Current arithmetic expression entered by the user */
  let expression = '';

  /**
   * Updates the calculator display.
   * Shows the current expression or a default "0" when empty.
   */
  const updateDisplay = () => {
    display.textContent = expression || '0';
  };

  /**
   * Sends the current expression to the backend for evaluation.
   * On success, shows the result; on error, displays an error message.
   */
  const calculate = async () => {
    try {
      const response = await fetch('/api/calculate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ expression }),
      });

      if (!response.ok) {
        // Backend returned an HTTP error status
        const errorText = await response.text();
        throw new Error(`Server error: ${response.status} ${errorText}`);
      }

      /** @type {{result?: number|string, error?: string}} */
      const data = await response.json();

      if (data.error) {
        expression = '';
        display.textContent = `Error: ${data.error}`;
      } else {
        // Show the result and allow further calculations using it
        const result = data.result;
        expression = String(result);
        display.textContent = expression;
      }
    } catch (err) {
      // Network or unexpected error
      console.error('Calculation failed:', err);
      expression = '';
      display.textContent = 'Error';
    }
  };

  /**
   * Handles a button press.
   * @param {string} value - The value associated with the button (e.g., "1", "+", "C", "=").
   */
  const handleButton = (value) => {
    switch (value) {
      case 'C': // Clear
        expression = '';
        updateDisplay();
        break;
      case '=': // Evaluate
        if (expression) {
          calculate();
        }
        break;
      default:
        // Append digit/operator to the expression
        expression += value;
        updateDisplay();
        break;
    }
  };

  // Attach click listeners to all calculator buttons
  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const value = btn.getAttribute('data-value');
      if (value) {
        handleButton(value);
      }
    });
  });

  /**
   * Maps keyboard keys to calculator button values.
   * Supports digits, basic operators, Enter (=), Backspace (C), and Escape (C).
   */
  const keyMap = {
    '0': '0',
    '1': '1',
    '2': '2',
    '3': '3',
    '4': '4',
    '5': '5',
    '6': '6',
    '7': '7',
    '8': '8',
    '9': '9',
    '.': '.',
    '+': '+',
    '-': '-',
    '*': '*',
    '/': '/',
    Enter: '=',
    '=': '=',
    Backspace: 'C',
    Escape: 'C',
  };

  // Keyboard support
  document.addEventListener('keydown', (e) => {
    const key = e.key;
    if (key in keyMap) {
      e.preventDefault(); // Prevent form submissions or page navigation
      handleButton(keyMap[key]);
    }
  });

  // Initial display state
  updateDisplay();
});