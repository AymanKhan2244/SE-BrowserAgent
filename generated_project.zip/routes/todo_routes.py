from flask import Blueprint, request, jsonify
from services.todo_service import TodoService
from models.todo_item import TodoItem
import logging

todo_routes = Blueprint("todo_routes", __name__)
todo_service = TodoService()
logging.basicConfig(level=logging.INFO)

@todo_routes.route("/todo-items", methods=["GET"])
def get_all_todo_items() -> dict:
    try:
        return jsonify(todo_service.get_all_todo_items())
    except Exception as e:
        logging.error(f"Error retrieving todo items: {e}")
        return jsonify({"error": "Failed to retrieve todo items"}), 500

@todo_routes.route("/todo-items", methods=["POST"])
def create_todo_item() -> dict:
    try:
        data = request.json
        if not data:
            return jsonify({"error": "Missing request body"}), 400
        if "title" not in data or "description" not in data:
            return jsonify({"error": "Missing title or description"}), 400
        todo_item = todo_service.create_todo_item(data["title"], data["description"])
        return jsonify(todo_item), 201
    except Exception as e:
        logging.error(f"Error creating todo item: {e}")
        return jsonify({"error": "Failed to create todo item"}), 500

@todo_routes.route("/todo-items/<int:id>", methods=["GET"])
def get_todo_item(id: int) -> dict:
    try:
        todo_item = todo_service.get_todo_item(id)
        if not todo_item:
            return jsonify({"error": "Todo item not found"}), 404
        return jsonify(todo_item)
    except Exception as e:
        logging.error(f"Error retrieving todo item: {e}")
        return jsonify({"error": "Failed to retrieve todo item"}), 500

@todo_routes.route("/todo-items/<int:id>", methods=["PUT"])
def update_todo_item(id: int) -> dict:
    try:
        data = request.json
        if not data:
            return jsonify({"error": "Missing request body"}), 400
        todo_item = todo_service.update_todo_item(id, data.get("title"), data.get("description"), data.get("completed"))
        if not todo_item:
            return jsonify({"error": "Todo item not found"}), 404
        return jsonify(todo_item)
    except Exception as e:
        logging.error(f"Error updating todo item: {e}")
        return jsonify({"error": "Failed to update todo item"}), 500

@todo_routes.route("/todo-items/<int:id>", methods=["DELETE"])
def delete_todo_item(id: int) -> dict:
    try:
        if not todo_service.delete_todo_item(id):
            return jsonify({"error": "Todo item not found"}), 404
        return jsonify({"message": "Todo item deleted"}), 200
    except Exception as e:
        logging.error(f"Error deleting todo item: {e}")
        return jsonify({"error": "Failed to delete todo item"}), 500