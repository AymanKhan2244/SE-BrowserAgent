# todo-app

## Setup

```bash
cd generated_project
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

## Entrypoint
`app.py`
