# basic-calculator

## Project Overview
**basic-calculator** is a minimal web application that provides a simple calculator interface. Users can input two numbers, select an arithmetic operation (add, subtract, multiply, divide), and receive the computed result instantly. The frontend is built with HTML, CSS, and vanilla JavaScript, while the backend is powered by Python Flask.

## Features
- Responsive UI with clean styling.
- Real‑time calculation via AJAX (fetch API).
- Input validation on both client and server sides.
- Clear error handling and user feedback.
- No external database – all processing is in‑memory.

## Prerequisites
- Python 3.9 or newer
- pip (Python package installer)

## Setup & Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/basic-calculator.git
   cd basic-calculator
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   # On Windows
   venv\Scripts\activate
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

## Running the Application

```bash
python app.py
```

The Flask development server will start and listen on `http://127.0.0.1:5000`. Open this URL in your browser to access the calculator UI.

## API Details

- **Endpoint:** `POST /api/calculate`
- **Request Body (JSON):**
  ```json
  {
    "a": 5,
    "b": 3,
    "operation": "add"
  }
  ```
  - `a` and `b` must be numbers (int or float).
  - `operation` must be one of: `add`, `subtract`, `multiply`, `divide`.

- **Successful Response (JSON):**
  ```json
  {
    "result": 8
  }
  ```

- **Error Response (JSON, HTTP 400):**
  ```json
  {
    "error": "Invalid operation supplied."
  }
  ```

## Folder Structure

```
basic-calculator/
├── app.py                 # Flask entry point, routes, and static file serving
├── services/
│   └── calculator.py      # Core arithmetic functions with validation
├── templates/
│   └── index.html         # Main UI page
├── static/
│   ├── style.css          # UI styling
│   └── script.js          # Front‑end logic & AJAX calls
├── requirements.txt       # Python dependencies
└── README.md              # This documentation
```

## Development Notes
- The Flask app uses `flask_cors.CORS` to allow same‑origin requests from the static files.
- All arithmetic logic resides in `services/calculator.py` to keep the API layer thin.
- Client‑side validation mirrors server‑side checks for a smoother UX.

## Contributing
Feel free to open issues or submit pull requests. Please ensure any new code follows the existing style (type hints, docstrings, and PEP 8 compliance).

## License
This project is released under the MIT License. See the `LICENSE` file for details.