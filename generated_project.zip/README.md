# basic-calculator

## Overview
A minimal web‑based calculator that performs the four basic arithmetic operations (addition, subtraction, multiplication, division).  
The frontend is built with plain HTML, CSS, and JavaScript. The backend is a Flask API that safely evaluates arithmetic expressions and returns the result as JSON.

## Features
- Responsive UI that works on desktop and mobile browsers  
- Real‑time expression building with button clicks and keyboard support  
- Secure evaluation of arithmetic expressions (no `eval`)  
- JSON API endpoint (`/api/calculate`) that returns `{ "result": <number> }` or an error message  
- CORS enabled for seamless interaction between frontend and backend  

## Prerequisites
- Python 3.9 or newer  
- Git (optional, for cloning the repository)  

## Installation

```bash
# 1. Clone the repository (or download the source archive)
git clone https://github.com/yourusername/basic-calculator.git
cd basic-calculator

# 2. Create a virtual environment
python -m venv venv
# On Windows
venv\Scripts\activate
# On macOS/Linux
source venv/bin/activate

# 3. Install Python dependencies
pip install -r requirements.txt
```

## Running the Application

```bash
# From the project root
python app.py
```

The server starts in development mode on `http://127.0.0.1:5000`.  
Open that URL in a web browser to use the calculator.

## API

### POST `/api/calculate`
**Request body (JSON)**
```json
{
  "expression": "12 / (3 + 1)"
}
```

**Successful response (200)**
```json
{
  "result": 3.0
}
```

**Error response (400)**
```json
{
  "error": "Invalid expression"
}
```

The API only accepts numbers, parentheses, and the operators `+ - * /`. Any other characters result in a 400 error.

## Frontend Usage
- Click the calculator buttons or type on your keyboard to build an expression.  
- Press **=** (or Enter) to send the expression to the backend.  
- The result appears in the display area.  

All UI assets are served from the Flask app, so no additional build steps are required.

## Development Notes
- The expression evaluator lives in `calculator/services.py` and uses Python’s `ast` module to parse and safely compute the result.  
- CORS is enabled via Flask‑CORS in `app.py` to allow the frontend JavaScript to call the API without cross‑origin issues.  
- To modify the UI, edit `templates/index.html`, `static/css/style.css`, or `static/js/app.js`.  
- To add more operations, extend the `_OPERATORS` mapping in `services.py` and update the frontend accordingly.

## License
This project is released under the MIT License. Feel free to use, modify, and distribute it as you see fit.