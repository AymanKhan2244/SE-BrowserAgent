# Basic Calculator

A minimal web application that provides a simple calculator UI.  
The frontend (plain HTML/CSS) lets users input two numbers and choose an operation.  
The backend (Python Flask) exposes a `/calculate` REST endpoint that performs the calculation and returns JSON.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Running the Application](#running-the-application)
- [Using the Calculator](#using-the-calculator)
- [API Reference](#api-reference)
- [Project Structure](#project-structure)
- [Testing the API with `curl`](#testing-the-api-with-curl)
- [Troubleshooting](#troubleshooting)
- [License](#license)

---

## Prerequisites

- Python 3.9 or newer
- `pip` (Python package installer)
- A modern web browser (Chrome, Firefox, Edge, Safari, etc.)

---

## Installation

1. **Clone the repository** (or copy the source files into a directory):

   ```bash
   git clone https://github.com/yourusername/basic-calculator.git
   cd basic-calculator
   ```

2. **Create a virtual environment** (recommended):

   ```bash
   python -m venv venv
   # On Windows
   venv\Scripts\activate
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**:

   ```bash
   pip install -r requirements.txt
   ```

   The `requirements.txt` contains:

   ```
   Flask>=2.3.0
   Flask-Cors>=4.0.0
   ```

---

## Running the Application

Start the Flask development server:

```bash
python app.py
```

The server will listen on `http://0.0.0.0:5000` by default.  
Open a browser and navigate to:

```
http://localhost:5000/
```

You should see the calculator UI.

*Optional*: Override the default port with the `PORT` environment variable:

```bash
export PORT=8080   # macOS/Linux
set PORT=8080      # Windows CMD
python app.py
```

---

## Using the Calculator

1. Enter a number in **Number A**.
2. Enter a number in **Number B**.
3. Choose an operation: **Add**, **Subtract**, **Multiply**, or **Divide**.
4. Click **Calculate**.
5. The result will appear below the form.

All calculations are performed on the server via the `/calculate` endpoint.

---

## API Reference

### `POST /calculate`

Performs a calculation based on the supplied JSON payload.

**Request Body (JSON)**

```json
{
  "a": <number>,
  "b": <number>,
  "op": "add" | "subtract" | "multiply" | "divide"
}
```

- `a` – first operand (numeric, integer or float)
- `b` – second operand (numeric)
- `op` – operation identifier

**Responses**

- **200 OK**

  ```json
  {
    "result": <number>
  }
  ```

- **400 Bad Request** (invalid input)

  ```json
  {
    "error": "<human‑readable error message>"
  }
  ```

**Error Cases**

- Missing fields (`a`, `b`, or `op`)
- Non‑numeric `a` or `b`
- Invalid `op` value
- Division by zero

---

## Project Structure

```
basic-calculator/
│
├─ app.py               # Flask app, routes, and calculation logic
├─ requirements.txt     # Python dependencies
├─ README.md            # This documentation
│
└─ static/
   ├─ index.html        # Frontend UI
   └─ styles.css        # Styling for the UI
```

All static files are served automatically by Flask from the `static/` directory.

---

## Testing the API with `curl`

```bash
curl -X POST http://localhost:5000/calculate \
     -H "Content-Type: application/json" \
     -d '{"a": 12, "b": 4, "op": "divide"}'
```

Expected response:

```json
{
  "result": 3.0
}
```

Try an error case (division by zero):

```bash
curl -X POST http://localhost:5000/calculate \
     -H "Content-Type: application/json" \
     -d '{"a": 5, "b": 0, "op": "divide"}'
```

Response:

```json
{
  "error": "Division by zero is not allowed"
}
```

---

## Troubleshooting

- **`ImportError: No module named flask`** – Ensure the virtual environment is activated and dependencies are installed (`pip install -r requirements.txt`).
- **Port already in use** – Choose a different port via the `PORT` environment variable.
- **CORS errors** – The backend enables CORS for all routes (`Flask-Cors`). If you serve the frontend from a different host/port, the API will still be reachable.

---

## License

This project is released under the MIT License. Feel free to use, modify, and distribute it.